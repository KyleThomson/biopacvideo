﻿namespace ProjectManager
{
    partial class WeightAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.A1 = new System.Windows.Forms.TextBox();
            this.W1 = new System.Windows.Forms.TextBox();
            this.A2 = new System.Windows.Forms.TextBox();
            this.W2 = new System.Windows.Forms.TextBox();
            this.DateBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.P1 = new System.Windows.Forms.TextBox();
            this.P2 = new System.Windows.Forms.TextBox();
            this.P4 = new System.Windows.Forms.TextBox();
            this.P3 = new System.Windows.Forms.TextBox();
            this.W4 = new System.Windows.Forms.TextBox();
            this.A4 = new System.Windows.Forms.TextBox();
            this.W3 = new System.Windows.Forms.TextBox();
            this.A3 = new System.Windows.Forms.TextBox();
            this.P6 = new System.Windows.Forms.TextBox();
            this.P5 = new System.Windows.Forms.TextBox();
            this.W6 = new System.Windows.Forms.TextBox();
            this.A6 = new System.Windows.Forms.TextBox();
            this.W5 = new System.Windows.Forms.TextBox();
            this.A5 = new System.Windows.Forms.TextBox();
            this.P8 = new System.Windows.Forms.TextBox();
            this.P7 = new System.Windows.Forms.TextBox();
            this.W8 = new System.Windows.Forms.TextBox();
            this.A8 = new System.Windows.Forms.TextBox();
            this.W7 = new System.Windows.Forms.TextBox();
            this.A7 = new System.Windows.Forms.TextBox();
            this.P10 = new System.Windows.Forms.TextBox();
            this.P9 = new System.Windows.Forms.TextBox();
            this.W10 = new System.Windows.Forms.TextBox();
            this.A10 = new System.Windows.Forms.TextBox();
            this.W9 = new System.Windows.Forms.TextBox();
            this.A9 = new System.Windows.Forms.TextBox();
            this.P12 = new System.Windows.Forms.TextBox();
            this.P11 = new System.Windows.Forms.TextBox();
            this.W12 = new System.Windows.Forms.TextBox();
            this.A12 = new System.Windows.Forms.TextBox();
            this.W11 = new System.Windows.Forms.TextBox();
            this.A11 = new System.Windows.Forms.TextBox();
            this.PelletsLabl = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // A1
            // 
            this.A1.Location = new System.Drawing.Point(13, 25);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(100, 20);
            this.A1.TabIndex = 0;
            // 
            // W1
            // 
            this.W1.Location = new System.Drawing.Point(119, 25);
            this.W1.Name = "W1";
            this.W1.Size = new System.Drawing.Size(100, 20);
            this.W1.TabIndex = 1;
            // 
            // A2
            // 
            this.A2.Location = new System.Drawing.Point(13, 51);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(100, 20);
            this.A2.TabIndex = 3;
            // 
            // W2
            // 
            this.W2.Location = new System.Drawing.Point(119, 51);
            this.W2.Name = "W2";
            this.W2.Size = new System.Drawing.Size(100, 20);
            this.W2.TabIndex = 4;
            // 
            // DateBox
            // 
            this.DateBox.Location = new System.Drawing.Point(12, 350);
            this.DateBox.Name = "DateBox";
            this.DateBox.Size = new System.Drawing.Size(100, 20);
            this.DateBox.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 100;
            this.label1.Text = "Animal ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(119, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 101;
            this.label2.Text = "Weight (g)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 334);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 99;
            this.label3.Text = "Date";
            // 
            // P1
            // 
            this.P1.Location = new System.Drawing.Point(225, 25);
            this.P1.Name = "P1";
            this.P1.Size = new System.Drawing.Size(100, 20);
            this.P1.TabIndex = 2;
            // 
            // P2
            // 
            this.P2.Location = new System.Drawing.Point(225, 51);
            this.P2.Name = "P2";
            this.P2.Size = new System.Drawing.Size(100, 20);
            this.P2.TabIndex = 5;
            // 
            // P4
            // 
            this.P4.Location = new System.Drawing.Point(225, 103);
            this.P4.Name = "P4";
            this.P4.Size = new System.Drawing.Size(100, 20);
            this.P4.TabIndex = 33;
            // 
            // P3
            // 
            this.P3.Location = new System.Drawing.Point(225, 77);
            this.P3.Name = "P3";
            this.P3.Size = new System.Drawing.Size(100, 20);
            this.P3.TabIndex = 30;
            // 
            // W4
            // 
            this.W4.Location = new System.Drawing.Point(119, 103);
            this.W4.Name = "W4";
            this.W4.Size = new System.Drawing.Size(100, 20);
            this.W4.TabIndex = 32;
            // 
            // A4
            // 
            this.A4.Location = new System.Drawing.Point(13, 103);
            this.A4.Name = "A4";
            this.A4.Size = new System.Drawing.Size(100, 20);
            this.A4.TabIndex = 31;
            // 
            // W3
            // 
            this.W3.Location = new System.Drawing.Point(119, 77);
            this.W3.Name = "W3";
            this.W3.Size = new System.Drawing.Size(100, 20);
            this.W3.TabIndex = 29;
            // 
            // A3
            // 
            this.A3.Location = new System.Drawing.Point(13, 77);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(100, 20);
            this.A3.TabIndex = 28;
            // 
            // P6
            // 
            this.P6.Location = new System.Drawing.Point(225, 155);
            this.P6.Name = "P6";
            this.P6.Size = new System.Drawing.Size(100, 20);
            this.P6.TabIndex = 39;
            // 
            // P5
            // 
            this.P5.Location = new System.Drawing.Point(225, 129);
            this.P5.Name = "P5";
            this.P5.Size = new System.Drawing.Size(100, 20);
            this.P5.TabIndex = 36;
            // 
            // W6
            // 
            this.W6.Location = new System.Drawing.Point(119, 155);
            this.W6.Name = "W6";
            this.W6.Size = new System.Drawing.Size(100, 20);
            this.W6.TabIndex = 38;
            // 
            // A6
            // 
            this.A6.Location = new System.Drawing.Point(13, 155);
            this.A6.Name = "A6";
            this.A6.Size = new System.Drawing.Size(100, 20);
            this.A6.TabIndex = 37;
            // 
            // W5
            // 
            this.W5.Location = new System.Drawing.Point(119, 129);
            this.W5.Name = "W5";
            this.W5.Size = new System.Drawing.Size(100, 20);
            this.W5.TabIndex = 35;
            // 
            // A5
            // 
            this.A5.Location = new System.Drawing.Point(13, 129);
            this.A5.Name = "A5";
            this.A5.Size = new System.Drawing.Size(100, 20);
            this.A5.TabIndex = 34;
            // 
            // P8
            // 
            this.P8.Location = new System.Drawing.Point(225, 207);
            this.P8.Name = "P8";
            this.P8.Size = new System.Drawing.Size(100, 20);
            this.P8.TabIndex = 45;
            // 
            // P7
            // 
            this.P7.Location = new System.Drawing.Point(225, 181);
            this.P7.Name = "P7";
            this.P7.Size = new System.Drawing.Size(100, 20);
            this.P7.TabIndex = 42;
            // 
            // W8
            // 
            this.W8.Location = new System.Drawing.Point(119, 207);
            this.W8.Name = "W8";
            this.W8.Size = new System.Drawing.Size(100, 20);
            this.W8.TabIndex = 44;
            // 
            // A8
            // 
            this.A8.Location = new System.Drawing.Point(13, 207);
            this.A8.Name = "A8";
            this.A8.Size = new System.Drawing.Size(100, 20);
            this.A8.TabIndex = 43;
            // 
            // W7
            // 
            this.W7.Location = new System.Drawing.Point(119, 181);
            this.W7.Name = "W7";
            this.W7.Size = new System.Drawing.Size(100, 20);
            this.W7.TabIndex = 41;
            // 
            // A7
            // 
            this.A7.Location = new System.Drawing.Point(13, 181);
            this.A7.Name = "A7";
            this.A7.Size = new System.Drawing.Size(100, 20);
            this.A7.TabIndex = 40;
            // 
            // P10
            // 
            this.P10.Location = new System.Drawing.Point(225, 259);
            this.P10.Name = "P10";
            this.P10.Size = new System.Drawing.Size(100, 20);
            this.P10.TabIndex = 51;
            // 
            // P9
            // 
            this.P9.Location = new System.Drawing.Point(225, 233);
            this.P9.Name = "P9";
            this.P9.Size = new System.Drawing.Size(100, 20);
            this.P9.TabIndex = 48;
            // 
            // W10
            // 
            this.W10.Location = new System.Drawing.Point(119, 259);
            this.W10.Name = "W10";
            this.W10.Size = new System.Drawing.Size(100, 20);
            this.W10.TabIndex = 50;
            // 
            // A10
            // 
            this.A10.Location = new System.Drawing.Point(13, 259);
            this.A10.Name = "A10";
            this.A10.Size = new System.Drawing.Size(100, 20);
            this.A10.TabIndex = 49;
            // 
            // W9
            // 
            this.W9.Location = new System.Drawing.Point(119, 233);
            this.W9.Name = "W9";
            this.W9.Size = new System.Drawing.Size(100, 20);
            this.W9.TabIndex = 47;
            // 
            // A9
            // 
            this.A9.Location = new System.Drawing.Point(13, 233);
            this.A9.Name = "A9";
            this.A9.Size = new System.Drawing.Size(100, 20);
            this.A9.TabIndex = 46;
            // 
            // P12
            // 
            this.P12.Location = new System.Drawing.Point(225, 311);
            this.P12.Name = "P12";
            this.P12.Size = new System.Drawing.Size(100, 20);
            this.P12.TabIndex = 57;
            // 
            // P11
            // 
            this.P11.Location = new System.Drawing.Point(225, 285);
            this.P11.Name = "P11";
            this.P11.Size = new System.Drawing.Size(100, 20);
            this.P11.TabIndex = 54;
            // 
            // W12
            // 
            this.W12.Location = new System.Drawing.Point(119, 311);
            this.W12.Name = "W12";
            this.W12.Size = new System.Drawing.Size(100, 20);
            this.W12.TabIndex = 56;
            // 
            // A12
            // 
            this.A12.Location = new System.Drawing.Point(13, 311);
            this.A12.Name = "A12";
            this.A12.Size = new System.Drawing.Size(100, 20);
            this.A12.TabIndex = 55;
            // 
            // W11
            // 
            this.W11.Location = new System.Drawing.Point(119, 285);
            this.W11.Name = "W11";
            this.W11.Size = new System.Drawing.Size(100, 20);
            this.W11.TabIndex = 53;
            // 
            // A11
            // 
            this.A11.Location = new System.Drawing.Point(13, 285);
            this.A11.Name = "A11";
            this.A11.Size = new System.Drawing.Size(100, 20);
            this.A11.TabIndex = 52;
            // 
            // PelletsLabl
            // 
            this.PelletsLabl.AutoSize = true;
            this.PelletsLabl.Location = new System.Drawing.Point(233, 9);
            this.PelletsLabl.Name = "PelletsLabl";
            this.PelletsLabl.Size = new System.Drawing.Size(38, 13);
            this.PelletsLabl.TabIndex = 102;
            this.PelletsLabl.Text = "Pellets";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(250, 340);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 59;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.OK_Click);
            // 
            // WeightAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(351, 400);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.PelletsLabl);
            this.Controls.Add(this.P12);
            this.Controls.Add(this.P11);
            this.Controls.Add(this.W12);
            this.Controls.Add(this.A12);
            this.Controls.Add(this.W11);
            this.Controls.Add(this.A11);
            this.Controls.Add(this.P10);
            this.Controls.Add(this.P9);
            this.Controls.Add(this.W10);
            this.Controls.Add(this.A10);
            this.Controls.Add(this.W9);
            this.Controls.Add(this.A9);
            this.Controls.Add(this.P8);
            this.Controls.Add(this.P7);
            this.Controls.Add(this.W8);
            this.Controls.Add(this.A8);
            this.Controls.Add(this.W7);
            this.Controls.Add(this.A7);
            this.Controls.Add(this.P6);
            this.Controls.Add(this.P5);
            this.Controls.Add(this.W6);
            this.Controls.Add(this.A6);
            this.Controls.Add(this.W5);
            this.Controls.Add(this.A5);
            this.Controls.Add(this.P4);
            this.Controls.Add(this.P3);
            this.Controls.Add(this.W4);
            this.Controls.Add(this.A4);
            this.Controls.Add(this.W3);
            this.Controls.Add(this.A3);
            this.Controls.Add(this.P2);
            this.Controls.Add(this.P1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DateBox);
            this.Controls.Add(this.W2);
            this.Controls.Add(this.A2);
            this.Controls.Add(this.W1);
            this.Controls.Add(this.A1);
            this.Name = "WeightAdd";
            this.Text = "Add Weight Measurement";
            this.Load += new System.EventHandler(this.WeightAdd_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox A1;
        private System.Windows.Forms.TextBox W1;
        private System.Windows.Forms.TextBox A2;
        private System.Windows.Forms.TextBox W2;
        private System.Windows.Forms.TextBox DateBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox P1;
        private System.Windows.Forms.TextBox P2;
        private System.Windows.Forms.TextBox P4;
        private System.Windows.Forms.TextBox P3;
        private System.Windows.Forms.TextBox W4;
        private System.Windows.Forms.TextBox A4;
        private System.Windows.Forms.TextBox W3;
        private System.Windows.Forms.TextBox A3;
        private System.Windows.Forms.TextBox P6;
        private System.Windows.Forms.TextBox P5;
        private System.Windows.Forms.TextBox W6;
        private System.Windows.Forms.TextBox A6;
        private System.Windows.Forms.TextBox W5;
        private System.Windows.Forms.TextBox A5;
        private System.Windows.Forms.TextBox P8;
        private System.Windows.Forms.TextBox P7;
        private System.Windows.Forms.TextBox W8;
        private System.Windows.Forms.TextBox A8;
        private System.Windows.Forms.TextBox W7;
        private System.Windows.Forms.TextBox A7;
        private System.Windows.Forms.TextBox P10;
        private System.Windows.Forms.TextBox P9;
        private System.Windows.Forms.TextBox W10;
        private System.Windows.Forms.TextBox A10;
        private System.Windows.Forms.TextBox W9;
        private System.Windows.Forms.TextBox A9;
        private System.Windows.Forms.TextBox P12;
        private System.Windows.Forms.TextBox P11;
        private System.Windows.Forms.TextBox W12;
        private System.Windows.Forms.TextBox A12;
        private System.Windows.Forms.TextBox W11;
        private System.Windows.Forms.TextBox A11;
        private System.Windows.Forms.Label PelletsLabl;
        private System.Windows.Forms.Button button1;
    }
}